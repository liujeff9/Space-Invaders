﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public AudioClip alienKnell;

    private Global globalObj;
    private Transform bullet;
    private float speed;
    
    // Start is called before the first frame update
    void Start()
    {
        GameObject g = GameObject.Find("GlobalObject");
        globalObj = g.GetComponent<Global>();
        bullet = gameObject.transform;
        speed = .35f;
    }

    void FixedUpdate()
    {
        bullet.position += Vector3.forward * speed;

        if (bullet.position.z >= 15)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider other) 
    {
        if (other.tag == "Alien")
        {
            AudioSource.PlayClipAtPoint(alienKnell, gameObject.transform.position);
            globalObj.score += other.gameObject.GetComponent<Alien>().points;
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
        else if (other.tag == "MysteryAlien")
        {
            AudioSource.PlayClipAtPoint(alienKnell, gameObject.transform.position);
            globalObj.score += Random.Range(30, 50);
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
        else if (other.tag == "Base")
        {
            other.gameObject.GetComponent<Base>().health -= 1;
            Destroy(gameObject);
        }
        else if (other.tag == "AlienBullet")
        {
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
    }
}
