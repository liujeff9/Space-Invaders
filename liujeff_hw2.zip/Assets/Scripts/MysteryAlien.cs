﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MysteryAlien : MonoBehaviour
{
    private Transform mysteryAlien;
    public float speed;

    void Start()
    {
        mysteryAlien = gameObject.transform;
        speed = .15f;
    }

    void FixedUpdate()
    {
        mysteryAlien.position += Vector3.right * speed;
        if (mysteryAlien.position.x >= 30)
        {
            Destroy(gameObject);
        }
    }
}
