﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Global : MonoBehaviour
{   
    public GameObject mysteryAlien;
    public static float minBound = -20.5f;
    public static float maxBound = 20.5f;
    public int score;
    public int highScore;
    public int lives;
    public bool gameOver;
    public bool gameWon;

    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        highScore = PlayerPrefs.GetInt("High Score");;
        lives = 3;
        gameOver = false;
        gameWon = false;
        SpawnMysteryAlien();
    }

    void SpawnMysteryAlien()
    {
        Vector3 spawnPos = new Vector3(-30f, 0, 10f);
        Instantiate(mysteryAlien, spawnPos, Quaternion.identity);
        float spawnTime = Random.Range(10f, 20f);
        Invoke("SpawnMysteryAlien", spawnTime);
    }
}
