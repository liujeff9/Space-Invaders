﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienBullet : MonoBehaviour
{
    private Transform alienBullet;
    private float speed;

    // Start is called before the first frame update
    void Start()
    {
        alienBullet = gameObject.transform;
        speed = .35f;
    }

    void FixedUpdate()
    {
        alienBullet.position += Vector3.forward * -1 * speed;

        if (alienBullet.position.z <= -25)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter(Collider other) 
    {
        if (other.tag == "Base")
        {
            other.gameObject.GetComponent<Base>().health -= 1;
            Destroy(gameObject);
        }
    }
}
