﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienParent : MonoBehaviour
{
    public AudioClip shotKnell;

    public GameObject alienBullet;
    private Global globalObj;
    private Transform alienParent;
    private float distance;

    // Start is called before the first frame update
    void Start()
    {
        GameObject g = GameObject.Find("GlobalObject");
        globalObj = g.GetComponent<Global>();
        alienParent = gameObject.transform;
        distance = 1f;
        InvokeRepeating("Move", .5f, .5f);
    }

    void Move()
    {
        alienParent.position += Vector3.right * distance;

        bool fired = false;
        foreach (Transform alien in alienParent)
        {
            // if an alien in on the edge, switch directions and move down
            if (alien.position.x < Global.minBound || alien.position.x > Global.maxBound)
            {
                distance *= -1;
                alienParent.position += Vector3.forward * -1;
                return;
            }

            // randomly fire bullets
            if (Random.Range(0f, 25.0f) < 1f && !fired)
            {
                AudioSource.PlayClipAtPoint(shotKnell, gameObject.transform.position);

                Vector3 spawnPos = alien.position;
                spawnPos.z -= 1f;
                Instantiate(alienBullet, spawnPos, Quaternion.Euler(90, 0, 0));
                fired = true;
            }
        }

        if (alienParent.childCount == 1)
        {
            CancelInvoke();
            InvokeRepeating("Move", .1f, .25f);
        }
        else if (alienParent.childCount == 0)
        {
            globalObj.gameWon = true;
        }
    }
}
