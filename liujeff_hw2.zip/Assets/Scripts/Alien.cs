﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Alien : MonoBehaviour
{
    private Global globalObj;
    public int points;
    
    void Start()
    {
        GameObject g = GameObject.Find("GlobalObject");
        globalObj = g.GetComponent<Global>();
    }

    void OnTriggerEnter(Collider other) 
    {
        if (other.tag == "Base")
        {
            Destroy(other.gameObject);
        }
    }
}
